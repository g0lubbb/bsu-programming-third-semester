import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TreeApp extends JFrame {
    private JTextArea outputArea;
    private JTextArea inputArea;
    private JTextArea treesStartingWithC;
    private List<Tree> trees;

    abstract static class Tree {
        protected String name;
        protected int age;
        protected TreeType type;
        protected static final double K = 1234;

        protected Tree(String name, int age, TreeType type) {
            this.name = name;
            this.age = age;
            this.type = type;
        }

        public abstract double calculateEfficiency();

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public TreeType getType() {
            return type;
        }
    }

    static class ForestTree extends Tree {
        private int woodQuantity;

        public ForestTree(String name, int age, int woodQuantity) {
            super(name, age, TreeType.FOREST);
            this.woodQuantity = woodQuantity;
        }

        @Override
        public double calculateEfficiency() {
            return age * K * woodQuantity;
        }
    }

    static class FruitTree extends Tree {
        private int fruitMass;
        private int storageDuration;

        public FruitTree(String name, int age, int fruitMass, int storageDuration) {
            super(name, age, TreeType.FRUIT);
            this.fruitMass = fruitMass;
            this.storageDuration = storageDuration;
        }

        @Override
        public double calculateEfficiency() {
            return age * K * fruitMass / storageDuration;
        }
    }

    enum TreeType {
        FOREST, FRUIT
    }


    static class TreeProcessor {
        public static List<Tree> sortByAgeDescending(List<Tree> trees) {
            trees.sort((t1, t2) -> {
                int ageComparison = Integer.compare(t2.getAge(), t1.getAge());
                return ageComparison != 0 ? ageComparison : t1.getName().compareTo(t2.getName());
            });
            return trees;
        }

        public static long countTreeType(List<Tree> trees, TreeType type) {
            return trees.stream()
                    .filter(tree -> tree.getType() == type)
                    .count();
        }

        public static List<String> findTreesStartingWithC(List<Tree> trees) {
            List<String> result = new ArrayList<>();
            for (Tree tree : trees) {
                if (tree.getName().startsWith("С") && !result.contains(tree.getName())) {
                    result.add(tree.getName());
                }
            }
            result.sort((s1, s2) -> s2.compareTo(s1));
            return result;
        }

    }

    public TreeApp() {
        setTitle("Обработка деревьев");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        outputArea = new JTextArea(15, 30);
        inputArea = new JTextArea(10, 30);
        treesStartingWithC = new JTextArea(10, 30);
        trees = new ArrayList<>();

        JButton loadButton = new JButton("Загрузить деревья");
        loadButton.addActionListener(new LoadButtonListener());

        JButton processButton = new JButton("Обработать деревья");
        processButton.addActionListener(new ProcessButtonListener());

        JButton findCButton = new JButton("Найти деревья на 'С'");
        findCButton.addActionListener(new FindCButtonListener());

        JPanel panel = new JPanel();
        panel.add(loadButton);
        panel.add(processButton);
        panel.add(findCButton);

        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(inputArea), BorderLayout.CENTER);
        add(new JScrollPane(outputArea), BorderLayout.EAST);
        add(new JScrollPane(treesStartingWithC), BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    private class LoadButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(TreeApp.this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                loadTreesFromFile(selectedFile);
            }
        }
    }

    private class ProcessButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            outputArea.setText("");
            if (trees.isEmpty()) {
                outputArea.append("Деревья не загружены.\n");
                return;
            }
            outputArea.append("Деревья, отсортированные по возрасту (убывание):\n");
            List<Tree> sortedByAge = TreeProcessor.sortByAgeDescending(trees);
            sortedByAge.forEach(tree -> outputArea.append(tree.getName() + "\n"));

            long forestCount = TreeProcessor.countTreeType(trees, TreeType.FOREST);
            outputArea.append("\nКоличество лесных деревьев: " + forestCount + "\n");

            long fruitCount = TreeProcessor.countTreeType(trees, TreeType.FRUIT);
            outputArea.append("Количество плодовых деревьев: " + fruitCount + "\n");
        }
    }

    private class FindCButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            treesStartingWithC.setText("");
            List<String> treesWithC = TreeProcessor.findTreesStartingWithC(trees);
            if (treesWithC.isEmpty()) {
                treesStartingWithC.append("Нет деревьев, начинающихся на 'С'.\n");
            } else {
                treesStartingWithC.append("Деревья, начинающиеся на 'С':\n");
                treesWithC.forEach(treeName -> treesStartingWithC.append(treeName + "\n"));
            }
        }
    }

    private void loadTreesFromFile(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    trees.add(new ForestTree(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2])));
                } else if (parts.length == 4) {
                    trees.add(new FruitTree(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                }
            }
            StringBuilder loadedTrees = new StringBuilder("Загруженные деревья:\n");
            for (Tree tree : trees) {
                loadedTrees.append(tree.getName()).append("\n");
            }
            inputArea.setText(loadedTrees.toString());
        } catch (IOException ex) {
            outputArea.append("Ошибка чтения файла: " + ex.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TreeApp::new);
    }
}