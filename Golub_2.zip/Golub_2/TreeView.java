import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TreeView {
    private JFrame frame;
    private JTextField inputField;
    private JButton addButton;
    private JButton minButton;
    private JButton visitButton;
    private JButton saveButton;
    private JTextArea outputArea;
    private TreeController controller;

    public TreeView(TreeController controller) {
        this.controller = controller;
        createUI();
    }

    private void createUI() {
        frame = new JFrame("Binary Tree Controller");
        inputField = new JTextField(10);
        addButton = new JButton("Добавить");
        minButton = new JButton("Минимум");
        visitButton = new JButton("Префиксный обход");
        saveButton = new JButton("Сохранить");
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int value = Integer.parseInt(inputField.getText());
                    controller.addValue(value);
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    showMessage("Введите корректное число!");
                }
            }
        });

        minButton.addActionListener(e -> controller.displayMin());
        visitButton.addActionListener(e -> controller.visitTree());
        saveButton.addActionListener(e -> controller.saveTree("tree.dat"));

        JPanel panel = new JPanel();
        panel.add(inputField);
        panel.add(addButton);
        panel.add(minButton);
        panel.add(visitButton);
        panel.add(saveButton);
        
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void clear() {
        outputArea.setText("");
    }

    public void displayTree(List<Integer> tree) {
        outputArea.append("Дерево: " + tree + "\n");
    }

    public void displayMin(int min) {
        outputArea.append("Минимум: " + min + "\n");
    }

    public void displayPathToMin(List<Integer> path) {
        outputArea.append("Путь к минимуму: " + path + "\n");
    }

    public void displayPrefixTraversal(List<Integer> traversal) {
        outputArea.append("Префиксный обход: " + traversal + "\n");
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(frame, message);
    }

    public JFrame getFrame() {
        return frame;
    }
}