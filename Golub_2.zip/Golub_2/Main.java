public class Main {
    public static void main(String[] args) {
        // M - BinaryTree(активная)
        // V - TreeView
        // C - TreeController
        BinaryTree binaryTree = new BinaryTree();
        TreeController controller = new TreeController(binaryTree);
        TreeView treeView = new TreeView(controller);
        controller.setView(treeView);
    }
}