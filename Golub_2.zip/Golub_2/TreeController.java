import javax.swing.*;

public class TreeController {
    private BinaryTree model;
    private TreeView view;

    public TreeController(BinaryTree model) {
        this.model = model;
    }

    public void setView(TreeView view) {
        this.view = view;
    }

    public void addValue(int value) {
        model.add(value);
        updateView();
    }

    public void saveTree(String filename) {
        model.save(filename);
        JOptionPane.showMessageDialog(view.getFrame(), "Дерево сохранено в " + filename);
    }

    public void displayMin() {
        MinStrategy strategy = new MinStrategyImpl();
        int min = strategy.findMin(model);
        view.displayMin(min);
    }

    public void visitTree() {
        PrintVisitor printVisitor = new PrintVisitor();
        model.accept(printVisitor);
        JOptionPane.showMessageDialog(view.getFrame(), "Префиксный обход завершен. Проверьте консоль.");
    }

    private void updateView() {
        view.clear();
        view.displayTree(model.getTree());
        view.displayMin(model.min());
        view.displayPathToMin(model.moveToMin());
        view.displayPrefixTraversal(model.prefixTraversal());
    }
}