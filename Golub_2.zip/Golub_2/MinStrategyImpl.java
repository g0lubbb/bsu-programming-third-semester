public class MinStrategyImpl implements MinStrategy {
    @Override
    public int findMin(BinaryTree tree) {
        return tree.min();
    }
}