public class PrintVisitor implements Visitor {
    @Override
    public void visit(int value) {
        System.out.print(value + " ");
    }
}