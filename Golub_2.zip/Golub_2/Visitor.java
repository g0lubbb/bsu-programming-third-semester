public interface Visitor {
    void visit(int value);
}