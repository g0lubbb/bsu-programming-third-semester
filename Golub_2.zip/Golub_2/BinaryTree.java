import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BinaryTree {
    private List<Integer> tree;

    public BinaryTree() {
        this.tree = new ArrayList<>();
    }

    public void add(int value) {
        if (tree.isEmpty()) {
            tree.add(value);
            return;
        }
        addRecursive(0, value);
    }
    
    private void addRecursive(int index, int value) {
        while (index >= tree.size()) {
            tree.add(0);
        }
        if (tree.get(index) == 0) {
            tree.set(index, value); 
        } else if (value < tree.get(index)) {
            addRecursive(2 * index + 1, value); 
        } else {
            addRecursive(2 * index + 2, value);
        }
    }

    public List<Integer> prefixTraversal() {
        List<Integer> result = new ArrayList<>();
        prefixTraversalRecursive(0, result);
        return result;
    }

    private void prefixTraversalRecursive(int index, List<Integer> result) {
        if (index >= tree.size() || tree.get(index) == 0) {
            return;
        }
        result.add(tree.get(index));
        prefixTraversalRecursive(2 * index + 1, result);
        prefixTraversalRecursive(2 * index + 2, result);
    }

    public int min() {
        return minRecursive(0);
    }

    private int minRecursive(int index) {
        if (index >= tree.size() || tree.get(index) == 0) {
            return Integer.MAX_VALUE;
        }
        int minValue = tree.get(index);
        int leftMin = minRecursive(2 * index + 1);
        int rightMin = minRecursive(2 * index + 2);
        return Math.min(minValue, Math.min(leftMin, rightMin));
    }

    public List<Integer> moveToMin() {
        List<Integer> path = new ArrayList<>();
        moveToMinRecursive(0, path);
        return path;
    }

    private boolean moveToMinRecursive(int index, List<Integer> path) {
        if (index >= tree.size() || tree.get(index) == 0) {
            return false;
        }
        path.add(tree.get(index));
        if (moveToMinRecursive(2 * index + 1, path)) {
            return true;
        }
        return moveToMinRecursive(2 * index + 2, path);
    }

    public List<Integer> getTree() {
        return tree;
    }

    public void save(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Integer value : tree) {
                writer.write(value.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }

    public void accept(Visitor visitor) {
        acceptRecursive(0, visitor);
    }

    private void acceptRecursive(int index, Visitor visitor) {
        if (index < tree.size() && tree.get(index) != 0) {
            visitor.visit(tree.get(index));
            acceptRecursive(2 * index + 1, visitor);
            acceptRecursive(2 * index + 2, visitor);
        }
    }
}