public interface MinStrategy {
    int findMin(BinaryTree tree);
}