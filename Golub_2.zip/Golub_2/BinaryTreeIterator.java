import java.util.List;

public class BinaryTreeIterator implements MyIterator<Integer> {
    private BinaryTree tree;
    private int currentIndex; 

    public BinaryTreeIterator(BinaryTree tree) {
        this.tree = tree;
        first();
    }

    @Override
    public void first() {
        currentIndex = 0; 
    }

    @Override
    public void next() {
        if (!isDone()) {
            currentIndex++;
        }
    }

    @Override
    public boolean isDone() {
        return currentIndex >= tree.getTree().size() || tree.getTree().get(currentIndex) == 0;
    }

    @Override
    public Integer currentItem() {
        if (isDone()) {
            throw new IndexOutOfBoundsException("Итератор завершен");
        }
        return tree.getTree().get(currentIndex);
    }
}